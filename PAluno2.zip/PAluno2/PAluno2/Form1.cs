﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno2
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[2, 3];
            double soma = 0;
            double[] media = new double[2];
            int i;
            int j;
            string geral;

            for (i = 0; i < 2; i++)
            {
                soma = 0;
                geral = ($"Aluno:{i + 1}");

                for (j = 0; j < 3; j++)
                {                   
                    notas[i, j] = double.Parse(Microsoft.VisualBasic.Interaction.InputBox($"Professor {j + 1} digite a nota:"));
                    soma = soma + notas[i, j];
                    geral = geral + ($" Nota Professor {j + 1}: {notas[i, j]}");
                }
                media[i] = soma / 3;
                geral = geral + ($" Média: " + media[i]);
                listBox1.Items.Add(geral);
            }
            double medfinal = (media[0] + media[1])/ 2;
            geral = ($"Média Geral:{medfinal}");
            listBox1.Items.Add(geral);
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        
        }
    }
}
